![OmniIndex Logo](web/images/OmniIndexDark.png)
# OmniIndex Platform Management Console Web App
The project consists of
*.html files
*.css Stylesheet files
*.js Javascript files
All files held in the following folder structure
*/
*styles/
*images/
*scripts/
#
######With the top level folder (/) holding the index.html file
######The styles folder holding all of teh css files
######The images folder holding the png files
######And the scripts folder holding the javascript.

